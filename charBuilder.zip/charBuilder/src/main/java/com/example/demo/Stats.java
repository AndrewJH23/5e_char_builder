package com.example.demo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Stats {
	private int strength;
	private int dexterity;
	private int constitution;
	private int intellegence;
	private int wisdom;
	private int charisma;
}
